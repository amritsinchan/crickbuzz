import './App.css';
import Todo from './containers/todo/todo';

function App() {
  return (
    <Todo />
  );
}

export default App;
