import './App.css';
import React from 'react';
import Navigator from './navigator';

class App extends React.Component {
  render() {
    return (
      <div className="App">
          <Navigator />
      </div>
    );
  }
  
}


export default App;
